<?php
$ch = curl_init();

curl_setopt($ch,CURLOPT_URL,"https://www.ptt.cc/bbs/hotboards.html");   //抓PTT熱門看版
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch,CURLOPT_HEADER,0);

$output = curl_exec($ch);

curl_close($ch);
$doc = new DOMDocument();
libxml_use_internal_errors(true);
$doc->loadHTML($output);


$count = 0;
$xpath = new DOMXPath($doc);
$entries = $xpath->query('//*[@id="main-container"]/div[2]/div');   //用XPATH抓節點
DB::table('ptts')->truncate();      //清空資料庫
foreach($entries as $entry){
    $count ++;
    $pttNews = $xpath->query("./a/div",$entry);
    
    //將資料存到資料庫裡
    DB::table('ptts')->insert(['boardName' => $pttNews->item(0)->nodeValue, 'boardUsers' => $pttNews->item(1)->nodeValue,
    'boardClass' =>$pttNews->item(2)->nodeValue,'boardTitle' =>$pttNews->item(3)->nodeValue, 'created_at' => new Datetime, 'updated_at' => new Datetime ]);
    if($count>=10)      //只想抓前10
        break;
    }
    header("Location: /");
    exit();    
?>

<?php /**PATH C:\pttCrawler\resources\views/home/ptt.blade.php ENDPATH**/ ?>