<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Lab_CurlwithXpath_Ptt_Laravel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .modal-header, h4, .close {
            background-color: #5cb85c;
            color: white;
            text-align: center;
            font-size: 2em;
        }

        .modal-footer {
            background-color: #f9f9f9;
        }
        li{
            font-size: 1.5em;
        }
    </style>
</head>
<body>

<div class="container">

    <div class="row">

        <div class="col-sm-8">
            <h1>PTT熱門看板</h1>
        <h3>板名 / 踴躍用戶數 / 看板分類 / 看板標題<span class="pull-right">
                {{-- 透過表單完成爬PTT，轉到home/ptt完成爬蟲然後轉回 --}}
                <form action="home/ptt" method="post">
                    @csrf
                    <button title="Catch Ptt Top10" id="crwalItem" name="submitButton" type="submit" class="btn btn-warning btn-sm"><span class="glyphicon glyphicon-star-empty" aria-hidden="true"></span></button>&nbsp;
                    <button title="Add an item" id="newItem" type="button" class="btn btn-success btn-sm"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button></span></h3>
                </form>
            
            <ul id="latestNews" class="list-group">
                @foreach ($ptt as $pttUnit)
            <li class="list-group-item">{{$pttUnit->boardName}} / {{$pttUnit->boardUsers}} / {{$pttUnit->boardClass}} / {{$pttUnit->boardTitle}}<span class="pull-right">
            
                {{-- 透過表單完成編輯和刪除功能 --}}
                <form action="home/{{$pttUnit->id}}" method="post"> 
                <button title="Edit"  class="btn btn-info btn-sm editItem" type="button" value="{{$pttUnit->id}}"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></button>&nbsp;
                    @csrf
                    @method('DELETE')
                <button title="Delete" class="btn btn-danger btn-sm " type="submit"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button></span></li>
                </form>
                    
                @endforeach
            </ul>
        </div>

        <div class="col-sm-4">
            &nbsp;
        </div>

    </div>  <!-- end of row -->

</div> <!-- end of container -->




<!-- 對話盒 -->
<div id="newsModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4>新增/修改</h4>
            </div>
            <div class="modal-body">
                <form action="/home" method="post">
                    @csrf
                    <div class="form-group">
                        <label for="boardName">
                            <span class="glyphicon glyphicon-tag"></span>
                            板名
                        </label>
                        <input type="text"
                               id="boardName"
                               name="boardName"
                               class="form-control"
                               placeholder="請輸入版名"/>
                    </div>

                    <div class="form-group">
                        <label for="boardUsers">
                            <span class="glyphicon glyphicon-user"></span>
                            踴躍用戶數
                        </label>
                        <input type="text"
                               id="boardUsers"
                               name="boardUsers"
                               class="form-control"
                               placeholder="50?200?"/>
                    </div>

                    <div class="form-group">
                        <label for="boardClass">
                            <span class="glyphicon glyphicon-th-large"></span>
                            看板分類
                        </label>
                        <input type="text"
                               id="boardClass"
                               name="boardClass"
                               class="form-control"
                               placeholder="分類項目例如：遊戲、籃球">
                    </div>

                    <div class="form-group">
                        <label for="boardTitle">
                            <span class="glyphicon glyphicon-bullhorn"></span>
                            看板標題
                        </label>
                        <input type="text"
                               id="boardTitle"
                               name="boardTitle"
                               class="form-control"
                               placeholder="例如：[政黑] 他奶奶的">
                    </div>


            </div>
        <div class="modal-footer">
            <div class="pull-right">
                        <button type="submit"
                        id="okButton"
                        class="btn btn-success">
                        <span class="glyphicon glyphicon-ok"></span> 確定
                    </button>
                    <button type="button"
                    id="cancelButton"
                    class="btn btn-default"
                    data-dismiss="modal">
                    <span class="glyphicon glyphicon-remove"></span> 取消
                </button>
            </div>
        </div>
    </form>

        </div>
    </div>
</div>
<!-- /對話盒 -->


<!-- ========== UI 與 JavaScript 分隔線 ========== -->


<script src="/js/jquery.js"></script>
<script src="/js/bootstrap.min.js"></script>

<script>

// 新增項目點擊跳出對話盒(值皆為空的))
$("#newItem").click(function(){
    $("#newsModal").modal( { backdrop: "static" } );
    $("#boardName").val('');   //板名
    $("#boardUsers").val('');  //踴躍用戶數
    $("#boardClass").val(''); //看板分類
    $("#boardTitle").val(''); //看板標題
});

//編輯項目
$(".editItem").click(function(){
    var index = $(".editItem").index(this);     //抓出點擊第幾個項目

    var temp ="{{$ptt}}";       //先將ptt的資料傳給temp(是字串))
    temp = temp.split("},");    //找出字串的分隔規則，並存成陣列
    temp = temp[index].split("&quot;")  //再將每一項細分成小項包含項目名稱和對應屬性

    $("#newsModal").modal( { backdrop: "static" } );    //叫出對話盒
    $("#boardName").val(temp[5]);   //板名
    $("#boardUsers").val(parseInt(temp[8].substr(1)));      //踴躍用戶數
    $("#boardClass").val(temp[11]); //看板分類
    $("#boardTitle").val(temp[15]); //看板標題
   
});

</script>




</body>
</html>